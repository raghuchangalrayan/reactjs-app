import React from 'react';
const MyComponent = () => {
    return (
      <div>
        <h1>Hello this my First React Component</h1>
      </div>
    );
  };
export default MyComponent;