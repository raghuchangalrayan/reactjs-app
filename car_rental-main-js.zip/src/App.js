import "./App.css";
import MyComponent from "./MyComponent";

function App() {
  return (
    <div className="App">
      <MyComponent />
    </div>
  );
}

export default App